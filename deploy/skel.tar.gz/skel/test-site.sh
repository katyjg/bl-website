#!/bin/bash

sudo docker-compose exec app /usr/bin/python3 /website/manage.py createsuperuser
sudo docker-compose exec app /usr/bin/python3 /website/manage.py testsite --beamline $1
