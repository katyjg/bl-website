# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = False

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'q07g43gkbqfz7dc236tq0498764jd897ch3jk29q177d93982d'

# SECURITY WARNING: define the correct hosts in production!
ALLOWED_HOSTS = ['*'] 

EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'website',
        'USER': 'website',
        'PASSWORD': 'Rewahgdasiu34jklvhjds93j',
        'HOST': 'website-db',
        'PORT': '',
    }
}

